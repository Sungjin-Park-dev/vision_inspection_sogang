#!/usr/bin/env python3
"""
메시 + 원래 viewpoint 카메라 pose + tilt waypoint pose 시각화 스크립트

사용 예:
  python ./scripts/visualize_tilt_on_mesh.py \
    --viewpoints data/viewpoint/1158/viewpoints.h5 \
    --mesh "" \
    --idx -1 \
    --roll-min -20 --roll-max 20 --roll-n 11 \
    --pitch-min -20 --pitch-max 20 --pitch-n 11
"""

import argparse
import numpy as np
import open3d as o3d

import os
import sys

# tilt.py 의 디렉토리 (scripts/)
THIS_DIR = os.path.dirname(os.path.abspath(__file__))
# scripts/ 의 상위 경로 (= project_root/)
PARENT_DIR = os.path.dirname(THIS_DIR)

# project_root/ 를 Python 경로에 추가
sys.path.append(PARENT_DIR)
# 프로젝트 공통 유틸 import
from common import config
from common.coordinate_utils import normalize_vectors, offset_points_along_normals
from common.trajectory_io import load_viewpoints_hdf5
from mesh_to_viewpoints import load_mesh_file
from tilt import generate_roll_pitch_tilts


# -------------------------------
# Rotation matrix → quaternion (xyzw)
# -------------------------------
def rot_to_quat_xyzw(R: np.ndarray) -> np.ndarray:
    """
    3x3 rotation matrix → quaternion [x, y, z, w]
    """
    R = np.asarray(R, dtype=float)
    t = np.trace(R)
    if t > 0.0:
        s = np.sqrt(t + 1.0) * 2.0
        w = 0.25 * s
        x = (R[2, 1] - R[1, 2]) / s
        y = (R[0, 2] - R[2, 0]) / s
        z = (R[1, 0] - R[0, 1]) / s
    else:
        # Trace가 가장 큰 축 기준으로 계산
        if R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
            s = np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2]) * 2.0
            w = (R[2, 1] - R[1, 2]) / s
            x = 0.25 * s
            y = (R[0, 1] + R[1, 0]) / s
            z = (R[0, 2] + R[2, 0]) / s
        elif R[1, 1] > R[2, 2]:
            s = np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2]) * 2.0
            w = (R[0, 2] - R[2, 0]) / s
            x = (R[0, 1] + R[1, 0]) / s
            y = 0.25 * s
            z = (R[1, 2] + R[2, 1]) / s
        else:
            s = np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1]) * 2.0
            w = (R[1, 0] - R[0, 1]) / s
            x = (R[0, 2] + R[2, 0]) / s
            y = (R[1, 2] + R[2, 1]) / s
            z = 0.25 * s

    q = np.array([x, y, z, w], dtype=float)
    # 정규화
    q /= np.linalg.norm(q) + 1e-9
    return q


# -------------------------------
# 카메라 pose 복원 (surface pos/normal + WD → cam pos & R)
# -------------------------------
def compute_camera_pose_from_surface(
    surface_pos: np.ndarray,
    surface_normal: np.ndarray,
    working_distance_m: float,
) -> (np.ndarray, np.ndarray):
    """
    surface_pos: (3,)  표면 점 (Z-up)
    surface_normal: (3,) 표면 법선 (unit)
    working_distance_m: 카메라 작업 거리

    return:
        cam_pos: (3,)
        R: (3,3)
    """
    n = surface_normal / (np.linalg.norm(surface_normal) + 1e-9)

    # 카메라는 표면을 바라보므로 카메라 방향 = - 표면 법선
    cam_dir = -n

    # 카메라 위치 = 표면점 + 법선 * WD
    cam_pos = surface_pos + n * working_distance_m

    # z축 = cam_dir
    z_axis = cam_dir / (np.linalg.norm(cam_dir) + 1e-9)

    # helper 축 선택 (compute_ik_solutions와 동일한 로직 유지)
    helper_z = np.array([0.0, 0.0, 1.0], dtype=np.float64)
    helper_y = np.array([0.0, 1.0, 0.0], dtype=np.float64)

    helper = helper_z if np.abs(np.dot(z_axis, helper_z)) <= 0.99 else helper_y
    x_axis = np.cross(helper, z_axis)
    nx = np.linalg.norm(x_axis)
    if nx < 1e-6:
        helper = helper_y if np.abs(np.dot(z_axis, helper_z)) > 0.99 else helper_z
        x_axis = np.cross(helper, z_axis)
        nx = np.linalg.norm(x_axis)
        if nx < 1e-6:
            raise ValueError("Failed to build camera x-axis")

    x_axis /= nx
    y_axis = np.cross(z_axis, x_axis)

    R = np.stack([x_axis, y_axis, z_axis], axis=1)  # columns: x,y,z
    return cam_pos, R


# -------------------------------
# Open3D Helper
# -------------------------------
def create_sphere(center, radius=0.003, color=(1.0, 0.0, 0.0)):
    m = o3d.geometry.TriangleMesh.create_sphere(radius=radius)
    m.translate(center)
    m.paint_uniform_color(color)
    return m


def create_camera_rays(poses: np.ndarray, target: np.ndarray, color=(0.0, 0.0, 1.0)):
    """
    poses: (N,4,4)
    target: (3,)
    """
    lines = []
    points = []
    colors = []

    target = np.asarray(target, dtype=float)

    for i, T in enumerate(poses):
        c = T[:3, 3]
        idx_cam = len(points)
        idx_tgt = len(points) + 1
        points.append(c)
        points.append(target)
        lines.append([idx_cam, idx_tgt])
        colors.append(color)

    if not points:
        return None

    ls = o3d.geometry.LineSet()
    ls.points = o3d.utility.Vector3dVector(np.asarray(points))
    ls.lines = o3d.utility.Vector2iVector(np.asarray(lines, dtype=np.int32))
    ls.colors = o3d.utility.Vector3dVector(np.asarray(colors))
    return ls


def create_pointcloud_from_poses(poses: np.ndarray, color=(0.0, 0.0, 1.0)):
    """
    poses: (N,4,4)
    """
    pts = poses[:, :3, 3]
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(pts)
    pcd.paint_uniform_color(color)
    return pcd


# -------------------------------
# 메인 함수
# -------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--viewpoints", required=True, help="viewpoints.h5 경로")
    ap.add_argument("--mesh", type=str, default="", help="mesh 파일 경로 (비우면 metadata/DEFAULT 사용)")
    ap.add_argument("--idx", type=int, default=-1, help="사용할 viewpoint index (-1이면 랜덤)")
    ap.add_argument("--roll-min", type=float, default=-20.0)
    ap.add_argument("--roll-max", type=float, default=20.0)
    ap.add_argument("--roll-n", type=int, default=11)
    ap.add_argument("--pitch-min", type=float, default=-20.0)
    ap.add_argument("--pitch-max", type=float, default=20.0)
    ap.add_argument("--pitch-n", type=int, default=11)
    args = ap.parse_args()

    # 1) viewpoints 로딩
    surface_positions, surface_normals, metadata = load_viewpoints_hdf5(args.viewpoints)
    N = surface_positions.shape[0]
    if N == 0:
        raise RuntimeError("No viewpoints in file")

    # 2) 사용할 index 선택 (랜덤 or 지정)
    if args.idx < 0 or args.idx >= N:
        vp_idx = np.random.randint(0, N)
        print(f"[INFO] Random viewpoint index selected: {vp_idx} / {N}")
    else:
        vp_idx = args.idx
        print(f"[INFO] Viewpoint index selected: {vp_idx} / {N}")

    surface_pos = surface_positions[vp_idx]
    surface_n = surface_normals[vp_idx]

    print(f"  Surface pos : {surface_pos}")
    print(f"  Surface normal : {surface_n}")

    # 3) working distance 결정 (metadata → 없으면 config)
    wd_m = config.get_camera_working_distance_m()
    if "camera_spec" in metadata and "working_distance_mm" in metadata["camera_spec"]:
        wd_m = metadata["camera_spec"]["working_distance_mm"] / 1000.0
        print(f"[INFO] Working distance from metadata: {wd_m:.4f} m")
    else:
        print(f"[INFO] Using default working distance from config: {wd_m:.4f} m")

    # 4) 원래 카메라 pose 복원
    cam_pos0, R0 = compute_camera_pose_from_surface(surface_pos, surface_n, wd_m)
    cam_quat_xyzw = rot_to_quat_xyzw(R0)

    print(f"  Camera pos (original): {cam_pos0}")
    print(f"  Camera quat [x,y,z,w]: {cam_quat_xyzw}")

    # 5) roll/pitch tilt pose 생성
    poses_roll, poses_pitch = generate_roll_pitch_tilts(
        cam_pos=cam_pos0,
        cam_quat_xyzw=cam_quat_xyzw,
        target_pos=surface_pos,
        roll_min_deg=args.roll_min,
        roll_max_deg=args.roll_max,
        n_roll=args.roll_n,
        pitch_min_deg=args.pitch_min,
        pitch_max_deg=args.pitch_max,
        n_pitch=args.pitch_n,
    )

    print(f"  Roll tilt poses:  {poses_roll.shape}")
    print(f"  Pitch tilt poses: {poses_pitch.shape}")

    # 6) mesh 로딩
    if args.mesh and len(args.mesh) > 0:
        mesh_path = args.mesh
    else:
        # metadata에 mesh_file 있으면 우선, 없으면 DEFAULT_MESH_FILE
        mesh_path = metadata.get("mesh_file", config.DEFAULT_MESH_FILE)
    print(f"[INFO] Using mesh file: {mesh_path}")

    mesh, _ = load_mesh_file(mesh_path)
    mesh.compute_vertex_normals()
    mesh.paint_uniform_color([0.75, 0.75, 0.75])

    # 7) Open3D geometry 준비
    geoms = [mesh]

    # target(surface point)
    target_sphere = create_sphere(surface_pos, radius=0.003, color=(1.0, 0.0, 0.0))
    geoms.append(target_sphere)

    # 원래 카메라 위치 + 좌표축
    base_cam_sphere = create_sphere(cam_pos0, radius=0.004, color=(0.0, 1.0, 0.0))
    geoms.append(base_cam_sphere)

    base_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.02)
    T0 = np.eye(4)
    T0[:3, :3] = R0
    T0[:3, 3] = cam_pos0
    base_frame.transform(T0)
    geoms.append(base_frame)

    # roll tilt path (파란 점 + 카메라→타겟 ray)
    pcd_roll = create_pointcloud_from_poses(poses_roll, color=(0.0, 0.0, 1.0))
    geoms.append(pcd_roll)
    rays_roll = create_camera_rays(poses_roll, surface_pos, color=(0.0, 0.0, 1.0))
    if rays_roll is not None:
        geoms.append(rays_roll)

    # pitch tilt path (보라색 점 + 카메라→타겟 ray)
    pcd_pitch = create_pointcloud_from_poses(poses_pitch, color=(0.6, 0.0, 0.6))
    geoms.append(pcd_pitch)
    rays_pitch = create_camera_rays(poses_pitch, surface_pos, color=(0.6, 0.0, 0.6))
    if rays_pitch is not None:
        geoms.append(rays_pitch)

    # roll / pitch의 첫/마지막 pose에 좌표축 프레임을 하나씩만 추가 (너무 많으면 지저분하니)
    for poses in [poses_roll, poses_pitch]:
        if poses.shape[0] > 0:
            for idx in [0, poses.shape[0] - 1]:
                T = poses[idx]
                frame = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.015)
                frame.transform(T)
                geoms.append(frame)

    # 8) 시각화 실행
    o3d.visualization.draw_geometries(
        geoms,
        window_name=f"Viewpoint {vp_idx} - tilt visualization",
        width=1280,
        height=720,
    )


if __name__ == "__main__":
    main()
