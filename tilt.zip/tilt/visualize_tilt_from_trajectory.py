#!/usr/bin/env python3
"""
joint_trajectory_dp.csv 에서 하나의 pose를 골라
- 그 pose를 초기 카메라 pose로 사용
- 해당 pose 기준 roll/pitch tilt waypoint 생성
- 메쉬 + 타겟 점 + 원래 pose + tilt 경로 시각화

사용 예:

  cd scripts

  python ./scripts/visualize_tilt_from_trajectory.py \
    --traj /home/lbj/curobo/vision_inspection/data/trajectory/675/gtsp_modified.csv \
    --row-idx 100 \
    --mesh "" \
    --roll-min -20 --roll-max 20 --roll-n 11 \
    --pitch-min -20 --pitch-max 20 --pitch-n 11
"""

import argparse
import csv
import os
import sys

import numpy as np
import open3d as o3d

# ---------------------------------------------------------------------
# 경로 설정: scripts/ 상위 폴더를 sys.path에 추가해서 common 모듈 import
# ---------------------------------------------------------------------
THIS_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.abspath(os.path.join(THIS_DIR, ".."))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

# 프로젝트 공통 모듈 및 tilt 유틸
from common import config
from mesh_to_viewpoints import load_mesh_file
from tilt import generate_roll_pitch_tilts, quat_xyzw_to_rot


# -------------------------------
# Open3D Helper
# -------------------------------
def create_sphere(center, radius=0.003, color=(1.0, 0.0, 0.0)):
    m = o3d.geometry.TriangleMesh.create_sphere(radius=radius)
    m.translate(center)
    m.paint_uniform_color(color)
    return m


def create_camera_rays(poses: np.ndarray, target: np.ndarray, color=(0.0, 0.0, 1.0)):
    """
    poses: (N,4,4)
    target: (3,)
    """
    lines = []
    points = []
    colors = []

    target = np.asarray(target, dtype=float)

    for i, T in enumerate(poses):
        c = T[:3, 3]
        idx_cam = len(points)
        idx_tgt = len(points) + 1
        points.append(c)
        points.append(target)
        lines.append([idx_cam, idx_tgt])
        colors.append(color)

    if not points:
        return None

    ls = o3d.geometry.LineSet()
    ls.points = o3d.utility.Vector3dVector(np.asarray(points))
    ls.lines = o3d.utility.Vector2iVector(np.asarray(lines, dtype=np.int32))
    ls.colors = o3d.utility.Vector3dVector(np.asarray(colors))
    return ls


def create_pointcloud_from_poses(poses: np.ndarray, color=(0.0, 0.0, 1.0)):
    """
    poses: (N,4,4)
    """
    pts = poses[:, :3, 3]
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(pts)
    pcd.paint_uniform_color(color)
    return pcd


def load_world_mesh(mesh_path: str = "") -> o3d.geometry.TriangleMesh:
    """
    메시를 로드한 뒤, config에 정의된 GLASS_POSITION / GLASS_ROTATION을 사용해서
    월드 좌표계 위치로 옮긴다.
    """
    # 1) 실제 사용할 mesh 파일 경로 결정
    if mesh_path and len(mesh_path) > 0:
        path = mesh_path
    else:
        path = config.DEFAULT_MESH_FILE
    print(f"[INFO] Using mesh file: {path}")

    # 2) 로컬 좌표계 메시 로드
    mesh, _ = load_mesh_file(path)
    mesh.compute_vertex_normals()
    mesh.paint_uniform_color([0.75, 0.75, 0.75])

    # 3) Glass object의 월드 포즈 적용
    #    - GLASS_ROTATION: quat (w, x, y, z)
    #    - GLASS_POSITION: (x, y, z)
    glass_pos = config.GLASS_POSITION      # shape (3,)
    glass_quat = config.GLASS_ROTATION     # shape (4,) (w, x, y, z)

    R_go = config.quaternion_to_rotation_matrix(glass_quat)  # (3,3)

    # 로컬 → 월드: 먼저 회전, 그 다음 평행이동
    mesh.rotate(R_go, center=[0.0, 0.0, 0.0])
    mesh.translate(glass_pos)

    return mesh


# -------------------------------
# CSV에서 pose 한 개 뽑기
# -------------------------------
def load_pose_from_trajectory_csv(traj_path: str, row_idx: int):
    """
    fk_gtsp_gpu_claude2.py 가 내보낸 joint_trajectory_dp.csv 스타일에서
    한 row를 골라 카메라 pose를 복원한다.

    지원 헤더(둘 중 하나):
      - fk_gtsp 스타일:
          target-POS_X, target-POS_Y, target-POS_Z,
          target-ROT_X, target-ROT_Y, target-ROT_Z, target-ROT_W
      - tilt_ik_pipeline 스타일:
          px, py, pz, qx, qy, qz, qw

    return:
        cam_pos      : (3,)
        cam_quat_xyzw: (4,) [x, y, z, w]
    """
    with open(traj_path, "r", newline="") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    if len(rows) == 0:
        raise RuntimeError(f"No rows found in CSV: {traj_path}")

    if row_idx < 0 or row_idx >= len(rows):
        print(
            f"[WARN] row_idx {row_idx} out of range [0,{len(rows)-1}], "
            f"clamping to middle."
        )
        row_idx = len(rows) // 2

    row = rows[row_idx]
    print(f"[INFO] Using row index: {row_idx} / {len(rows)-1}")

    # fk_gtsp 스타일인지, tilt_ik 스타일인지 확인
    fkgtsp_pos_keys = ["target-POS_X", "target-POS_Y", "target-POS_Z"]
    fkgtsp_rot_keys = ["target-ROT_X", "target-ROT_Y", "target-ROT_Z", "target-ROT_W"]

    if all(k in row for k in fkgtsp_pos_keys + fkgtsp_rot_keys):
        px = float(row["target-POS_X"])
        py = float(row["target-POS_Y"])
        pz = float(row["target-POS_Z"])
        qx = float(row["target-ROT_X"])
        qy = float(row["target-ROT_Y"])
        qz = float(row["target-ROT_Z"])
        qw = float(row["target-ROT_W"])
        print("[INFO] Detected fk_gtsp-style CSV columns.")
    else:
        # tilt_ik_pipeline 스타일 가정
        px = float(row["px"])
        py = float(row["py"])
        pz = float(row["pz"])
        qx = float(row["qx"])
        qy = float(row["qy"])
        qz = float(row["qz"])
        qw = float(row["qw"])
        print("[INFO] Detected tilt_ik_pipeline-style CSV columns.")

    cam_pos = np.array([px, py, pz], dtype=np.float64)
    cam_quat_xyzw = np.array([qx, qy, qz, qw], dtype=np.float64)

    print(f"  Camera pos from CSV: {cam_pos}")
    print(f"  Camera quat [x,y,z,w] from CSV: {cam_quat_xyzw}")

    return cam_pos, cam_quat_xyzw


# -------------------------------
# 메인
# -------------------------------
def main():
    ap = argparse.ArgumentParser(
        description="joint_trajectory_dp.csv 에서 pose 하나 골라 tilt 시각화"
    )
    ap.add_argument(
        "--traj",
        required=True,
        help="joint_trajectory_dp.csv 경로 (fk_gtsp_gpu_claude2.py export_to_csv 출력)",
    )
    ap.add_argument(
        "--row-idx",
        type=int,
        default=-1,
        help="사용할 CSV row index (0-based, 음수면 중간 row 사용)",
    )
    ap.add_argument(
        "--mesh",
        type=str,
        default="",
        help="mesh 파일 경로 (비우면 config.DEFAULT_MESH_FILE 사용)",
    )
    ap.add_argument("--roll-min", type=float, default=-20.0)
    ap.add_argument("--roll-max", type=float, default=20.0)
    ap.add_argument("--roll-n", type=int, default=11)
    ap.add_argument("--pitch-min", type=float, default=-20.0)
    ap.add_argument("--pitch-max", type=float, default=20.0)
    ap.add_argument("--pitch-n", type=int, default=11)
    args = ap.parse_args()

    # 1) CSV에서 pose 하나 읽기
    cam_pos0, cam_quat_xyzw = load_pose_from_trajectory_csv(args.traj, args.row_idx)

    # 2) working distance 가져오기 (config 또는 고정값)
    wd_m = config.get_camera_working_distance_m()
    print(f"[INFO] Using working distance: {wd_m:.4f} m")

    # 3) 쿼터니언 → 회전행렬, z축으로 타겟 점 근사
    R0 = quat_xyzw_to_rot(cam_quat_xyzw)
    z_axis = R0[:, 2]  # 카메라가 보는 방향 (z축)
    target_pos = cam_pos0 + z_axis * wd_m

    print(f"  Approximated target pos: {target_pos}")

    # 4) roll/pitch tilt pose 생성
    poses_roll, poses_pitch = generate_roll_pitch_tilts(
        cam_pos=cam_pos0,
        cam_quat_xyzw=cam_quat_xyzw,
        target_pos=target_pos,
        roll_min_deg=args.roll_min,
        roll_max_deg=args.roll_max,
        n_roll=args.roll_n,
        pitch_min_deg=args.pitch_min,
        pitch_max_deg=args.pitch_max,
        n_pitch=args.pitch_n,
    )

    print(f"  Roll tilt poses:  {poses_roll.shape}")
    print(f"  Pitch tilt poses: {poses_pitch.shape}")

    # 5) mesh 로딩
    if args.mesh and len(args.mesh) > 0:
        mesh_path = args.mesh
    else:
        mesh_path = config.DEFAULT_MESH_FILE
    print(f"[INFO] Using mesh file: {mesh_path}")

    mesh = load_world_mesh(mesh_path=args.mesh if hasattr(args, "mesh") else "")

    # 6) Open3D geometry 준비
    geoms = [mesh]

    # target 점 (근사)
    target_sphere = create_sphere(target_pos, radius=0.003, color=(1.0, 0.0, 0.0))
    geoms.append(target_sphere)

    # 원래 카메라 위치 + 좌표축
    base_cam_sphere = create_sphere(cam_pos0, radius=0.004, color=(0.0, 1.0, 0.0))
    geoms.append(base_cam_sphere)

    base_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.02)
    T0 = np.eye(4)
    T0[:3, :3] = R0
    T0[:3, 3] = cam_pos0
    base_frame.transform(T0)
    geoms.append(base_frame)

    # roll tilt path (파란 점 + 카메라→타겟 ray)
    if poses_roll.shape[0] > 0:
        pcd_roll = create_pointcloud_from_poses(poses_roll, color=(0.0, 0.0, 1.0))
        geoms.append(pcd_roll)
        rays_roll = create_camera_rays(poses_roll, target_pos, color=(0.0, 0.0, 1.0))
        if rays_roll is not None:
            geoms.append(rays_roll)

    # pitch tilt path (보라색 점 + 카메라→타겟 ray)
    if poses_pitch.shape[0] > 0:
        pcd_pitch = create_pointcloud_from_poses(poses_pitch, color=(0.6, 0.0, 0.6))
        geoms.append(pcd_pitch)
        rays_pitch = create_camera_rays(
            poses_pitch, target_pos, color=(0.6, 0.0, 0.6)
        )
        if rays_pitch is not None:
            geoms.append(rays_pitch)

    # roll / pitch의 첫/마지막 pose에 좌표축 프레임을 하나씩만 추가
    for poses in [poses_roll, poses_pitch]:
        if poses.shape[0] > 0:
            for idx in [0, poses.shape[0] - 1]:
                T = poses[idx]
                frame = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.015)
                frame.transform(T)
                geoms.append(frame)

    # 7) 시각화 실행
    o3d.visualization.draw_geometries(
        geoms,
        window_name=f"Tilt from trajectory pose (row {args.row_idx})",
        width=1280,
        height=720,
    )


if __name__ == "__main__":
    main()
