#!/usr/bin/env python3
import os
import sys
import argparse
import numpy as np

# -------------------------------------------------------------------------
# (선택) 프로젝트 모듈 import – viewpoints.h5 로딩용
#   - scripts/ 디렉토리에서 실행한다고 가정해 상위 경로를 path 에 추가
#   - common.trajectory_io.load_viewpoints_hdf5 를 재사용
# -------------------------------------------------------------------------
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '.')))
try:
    from common.trajectory_io import load_viewpoints_hdf5
    HAVE_TRAJ_IO = True
except ImportError:
    # 레포 없이 순수 기하만 테스트할 수도 있으니 graceful fallback
    HAVE_TRAJ_IO = False


# =====================================================================
# 기초 유틸
# =====================================================================
def normalize(v, eps=1e-9):
    v = np.asarray(v, dtype=float)
    n = np.linalg.norm(v)
    if n < eps:
        return v * 0.0
    return v / n


def quat_xyzw_to_rot(q):
    """
    q: (4,) quaternion in [x, y, z, w] format.
    return: 3x3 rotation matrix
    """
    x, y, z, w = q
    # 정규화
    n = np.sqrt(x * x + y * y + z * z + w * w)
    if n < 1e-9:
        return np.eye(3)
    x /= n
    y /= n
    z /= n
    w /= n

    xx, yy, zz = x * x, y * y, z * z
    xy, xz, yz = x * y, x * z, y * z
    wx, wy, wz = w * x, w * y, w * z

    R = np.array(
        [
            [1 - 2 * (yy + zz), 2 * (xy - wz), 2 * (xz + wy)],
            [2 * (xy + wz), 1 - 2 * (xx + zz), 2 * (yz - wx)],
            [2 * (xz - wy), 2 * (yz + wx), 1 - 2 * (xx + yy)],
        ]
    )
    return R


def rot_to_quat_xyzw(R):
    """
    3x3 회전행렬 -> quaternion [x,y,z,w]
    (world에서 camera로 가는 회전)
    """
    R = np.asarray(R, dtype=float)
    m00, m01, m02 = R[0, 0], R[0, 1], R[0, 2]
    m10, m11, m12 = R[1, 0], R[1, 1], R[1, 2]
    m20, m21, m22 = R[2, 0], R[2, 1], R[2, 2]

    tr = m00 + m11 + m22
    if tr > 0.0:
        S = np.sqrt(tr + 1.0) * 2.0
        w = 0.25 * S
        x = (m21 - m12) / S
        y = (m02 - m20) / S
        z = (m10 - m01) / S
    elif (m00 > m11) and (m00 > m22):
        S = np.sqrt(1.0 + m00 - m11 - m22) * 2.0
        w = (m21 - m12) / S
        x = 0.25 * S
        y = (m01 + m10) / S
        z = (m02 + m20) / S
    elif m11 > m22:
        S = np.sqrt(1.0 + m11 - m00 - m22) * 2.0
        w = (m02 - m20) / S
        x = (m01 + m10) / S
        y = 0.25 * S
        z = (m12 + m21) / S
    else:
        S = np.sqrt(1.0 + m22 - m00 - m11) * 2.0
        w = (m10 - m01) / S
        x = (m02 + m20) / S
        y = (m12 + m21) / S
        z = 0.25 * S

    q = np.array([x, y, z, w], dtype=float)
    q /= np.linalg.norm(q) + 1e-9
    return q


def rodrigues(axis, theta):
    """
    axis: (3,) 단위벡터
    theta: 라디안
    """
    axis = normalize(axis)
    x, y, z = axis
    c = np.cos(theta)
    s = np.sin(theta)
    C = 1.0 - c

    R = np.array(
        [
            [c + x * x * C, x * y * C - z * s, x * z * C + y * s],
            [y * x * C + z * s, c + y * y * C, y * z * C - x * s],
            [z * x * C - y * s, z * y * C + x * s, c + z * z * C],
        ]
    )
    return R


# =====================================================================
# 초기 카메라 frame 구성 (target p 를 보는 frame)
# =====================================================================
def build_initial_camera_frame(p, c0, R0):
    """
    p  : (3,) 타겟 점 (world)
    c0 : (3,) 초기 카메라 위치 (world)
    R0 : (3,3) 초기 카메라 회전 (world 기준)

    - z0: p를 바라보는 방향
    - up_ref: R0의 y축을 가능한 한 유지
    - x0, y0: z0와 up_ref로부터 재구성된 카메라 로컬 축
    """
    p = np.asarray(p, dtype=float)
    c0 = np.asarray(c0, dtype=float)

    # 타겟을 바라보는 방향 (카메라 z축)
    z0 = normalize(p - c0)  # "카메라가 보는 방향"

    # 초기 회전의 y축(위쪽) 방향을 가능한 한 유지
    up_ref = R0[:, 1]  # R0의 두 번째 column

    # up_ref와 z0가 거의 평행하면 다른 up을 사용
    if np.abs(np.dot(normalize(up_ref), z0)) > 0.99:
        up_ref = np.array([0.0, 0.0, 1.0], dtype=float)
        if np.abs(np.dot(normalize(up_ref), z0)) > 0.99:
            up_ref = np.array([0.0, 1.0, 0.0], dtype=float)

    # x축: up_ref × z0
    x0 = normalize(np.cross(up_ref, z0))
    # y축: z0 × x0
    y0 = np.cross(z0, x0)

    return x0, y0, z0


# =====================================================================
# tilt trajectory 생성 (roll 또는 pitch 한 축 기준)
# =====================================================================
def generate_tilt_trajectory_from_pose(
    cam_pos,
    cam_quat_xyzw,
    target_pos,
    axis_type="roll",
    angle_min_deg=-20.0,
    angle_max_deg=20.0,
    num_samples=11,
):
    """
    cam_pos       : (3,) 초기 카메라 위치 (world)
    cam_quat_xyzw : (4,) 초기 카메라 쿼터니언 [x, y, z, w] (world 기준)
    target_pos    : (3,) 바라볼 점 p (world)

    axis_type: "roll" 또는 "pitch"
        - "roll"  : 초기 카메라 x축 기준으로 tilt
        - "pitch" : 초기 카메라 y축 기준으로 tilt

    angle_min_deg, angle_max_deg : tilt 각도 범위 [deg]
    num_samples                  : 해당 범위를 균등 분할한 샘플 개수

    return:
        poses: (N, 4, 4) world 기준 카메라(=EE) pose 시퀀스
    """
    cam_pos = np.asarray(cam_pos, dtype=float)
    target_pos = np.asarray(target_pos, dtype=float)
    R0 = quat_xyzw_to_rot(np.asarray(cam_quat_xyzw, dtype=float))

    # 초기 카메라 로컬 축 (world 기준)
    x0, y0, z0 = build_initial_camera_frame(target_pos, cam_pos, R0)

    # 타겟 기준 초기 위치 벡터
    r0 = cam_pos - target_pos  # p에서 카메라까지

    # roll / pitch 축 및 "위쪽" 기준 벡터 정의
    if axis_type == "roll":
        axis = x0      # roll: 오른쪽 축 기준
    elif axis_type == "pitch":
        axis = y0      # pitch: 위쪽 축 기준
    else:
        raise ValueError("axis_type must be 'roll' or 'pitch'")

    # up 방향은 축과 상관없이 항상 초기 y축을 사용
    up_vec = y0

    # 각도 샘플
    angles_deg = np.linspace(angle_min_deg, angle_max_deg, num_samples)
    angles_rad = np.deg2rad(angles_deg)

    poses = []

    for theta in angles_rad:
        # 1) 위치: target_pos를 중심으로 r0를 axis 기준 회전
        R_axis = rodrigues(axis, theta)
        r = R_axis @ r0
        c = target_pos + r  # 카메라 위치

        # 2) 자세: 타겟을 바라보는 z축
        z_c = normalize(target_pos - c)

        # up_vec와 z_c가 너무 평행하면 fallback
        if np.abs(np.dot(normalize(up_vec), z_c)) > 0.99:
            alt_up = np.array([0.0, 0.0, 1.0], dtype=float)
            if np.abs(np.dot(normalize(alt_up), z_c)) > 0.99:
                alt_up = np.array([0.0, 1.0, 0.0], dtype=float)
            up = alt_up
        else:
            up = up_vec

        # x축, y축 계산
        x_c = normalize(np.cross(up, z_c))
        y_c = np.cross(z_c, x_c)

        R_c = np.column_stack([x_c, y_c, z_c])

        # homogeneous pose
        T = np.eye(4)
        T[:3, :3] = R_c
        T[:3, 3] = c

        poses.append(T)

    poses = np.stack(poses, axis=0)  # (N, 4, 4)
    return poses


def generate_roll_pitch_tilts(
    cam_pos,
    cam_quat_xyzw,
    target_pos,
    roll_min_deg=-20.0,
    roll_max_deg=20.0,
    n_roll=11,
    pitch_min_deg=-20.0,
    pitch_max_deg=20.0,
    n_pitch=11,
):
    """
    편의용: roll, pitch 두 가지 tilt waypoint를 한 번에 생성.
    """
    poses_roll = generate_tilt_trajectory_from_pose(
        cam_pos,
        cam_quat_xyzw,
        target_pos,
        axis_type="roll",
        angle_min_deg=roll_min_deg,
        angle_max_deg=roll_max_deg,
        num_samples=n_roll,
    )

    poses_pitch = generate_tilt_trajectory_from_pose(
        cam_pos,
        cam_quat_xyzw,
        target_pos,
        axis_type="pitch",
        angle_min_deg=pitch_min_deg,
        angle_max_deg=pitch_max_deg,
        num_samples=n_pitch,
    )

    return poses_roll, poses_pitch


# =====================================================================
# viewpoints.h5 에서 랜덤 viewpoint 뽑고 초기 pose + p 만들기
# =====================================================================
def sample_random_viewpoint_from_h5(
    viewpoints_path: str,
    working_distance_m: float | None = None,
    seed: int | None = None,
):
    """
    viewpoints.h5 (mesh_to_viewpoints.py 에서 저장한 파일)를 읽어서
    surface point + normal 하나를 랜덤 선택하고,
    그 점을 WD 만큼 떨어져 바라보는 카메라 pose 를 만든다.

    반환:
        idx          : 선택된 viewpoint 인덱스 (surface_points row index)
        target_pos   : (3,) world 기준 타겟 점 (지금은 object frame == world 라고 가정)
        cam_pos      : (3,) world 기준 카메라 위치
        cam_quat_xyzw: (4,) world 기준 카메라 쿼터니언 [x,y,z,w]
    """
    if not HAVE_TRAJ_IO:
        raise RuntimeError(
            "common.trajectory_io.load_viewpoints_hdf5 를 찾을 수 없습니다. "
            "레포 루트에서 실행 중인지 확인하거나, working_distance_m 과 "
            "surface_positions/normals 를 직접 불러서 써 주세요."
        )

    surface_positions, surface_normals, metadata = load_viewpoints_hdf5(
        viewpoints_path
    )
    surface_positions = np.asarray(surface_positions, dtype=float)
    surface_normals = np.asarray(surface_normals, dtype=float)

    n = surface_positions.shape[0]
    if n == 0:
        raise ValueError("viewpoints 파일에 surface_points 가 없습니다.")

    rng = np.random.default_rng(seed)
    idx = int(rng.integers(0, n))

    surf = surface_positions[idx]
    normal = normalize(surface_normals[idx])

    # working distance 결정
    if working_distance_m is None:
        wd_m = None
        if isinstance(metadata, dict) and "camera_spec" in metadata:
            cam_spec = metadata["camera_spec"]
            if isinstance(cam_spec, dict) and "working_distance_mm" in cam_spec:
                wd_m = cam_spec["working_distance_mm"] / 1000.0
        if wd_m is None:
            raise ValueError(
                "working_distance_m 이 주어지지 않았고, "
                "HDF5 metadata.camera_spec.working_distance_mm 도 없습니다."
            )
        working_distance_m = wd_m

    # 카메라 위치: surface_point + normal * WD
    cam_pos = surf + normal * working_distance_m

    # 카메라는 표면을 향해 본다 → 방향 = -normal 이 카메라 z축
    z_axis = normalize(-normal)

    # 초기 up 벡터 선택 (world z 와 너무 평행이면 y 사용)
    helper_z = np.array([0.0, 0.0, 1.0], dtype=float)
    helper_y = np.array([0.0, 1.0, 0.0], dtype=float)

    if np.abs(np.dot(z_axis, helper_z)) <= 0.99:
        helper = helper_z
    else:
        helper = helper_y

    x_axis = np.cross(helper, z_axis)
    nx = np.linalg.norm(x_axis)
    if nx < 1e-6:
        # 거의 평행해버린 경우 다른 helper
        helper = helper_y if helper is helper_z else helper_z
        x_axis = np.cross(helper, z_axis)
        nx = np.linalg.norm(x_axis)
        if nx < 1e-6:
            raise ValueError("직교 frame 생성 실패")

    x_axis /= nx
    y_axis = np.cross(z_axis, x_axis)

    R = np.column_stack([x_axis, y_axis, z_axis])
    cam_quat_xyzw = rot_to_quat_xyzw(R)

    target_pos = surf  # WD 앞에 있는 실제 표면 점

    return idx, target_pos, cam_pos, cam_quat_xyzw


def generate_tilts_for_random_viewpoint(
    viewpoints_path: str,
    working_distance_m: float | None = None,
    seed: int | None = None,
    roll_min_deg: float = -20.0,
    roll_max_deg: float = 20.0,
    n_roll: int = 11,
    pitch_min_deg: float = -20.0,
    pitch_max_deg: float = 20.0,
    n_pitch: int = 11,
):
    """
    1) viewpoints.h5 에서 랜덤 viewpoint 하나 선택
    2) 그 점을 보는 초기 카메라 pose 계산
    3) 그 pose 기준으로 roll / pitch tilt waypoint 들 생성
    """
    idx, target_pos, cam_pos, cam_quat = sample_random_viewpoint_from_h5(
        viewpoints_path=viewpoints_path,
        working_distance_m=working_distance_m,
        seed=seed,
    )

    poses_roll, poses_pitch = generate_roll_pitch_tilts(
        cam_pos=cam_pos,
        cam_quat_xyzw=cam_quat,
        target_pos=target_pos,
        roll_min_deg=roll_min_deg,
        roll_max_deg=roll_max_deg,
        n_roll=n_roll,
        pitch_min_deg=pitch_min_deg,
        pitch_max_deg=pitch_max_deg,
        n_pitch=n_pitch,
    )

    return {
        "index": idx,
        "target_pos": target_pos,
        "cam_pos": cam_pos,
        "cam_quat_xyzw": cam_quat,
        "poses_roll": poses_roll,
        "poses_pitch": poses_pitch,
    }


# =====================================================================
# 예시 main (간단 테스트용)
# =====================================================================
def main():
    ap = argparse.ArgumentParser(
        description="Random viewpoint를 하나 골라서 roll/pitch tilt waypoint 생성"
    )
    ap.add_argument(
        "--viewpoints",
        type=str,
        required=False,
        help="viewpoints.h5 경로 (mesh_to_viewpoints.py 출력)",
    )
    ap.add_argument(
        "--wd",
        type=float,
        default=None,
        help="working distance [m]. 생략 시 HDF5 metadata에서 시도",
    )
    ap.add_argument("--seed", type=int, default=None, help="랜덤 시드")
    ap.add_argument("--roll_min", type=float, default=-20.0)
    ap.add_argument("--roll_max", type=float, default=20.0)
    ap.add_argument("--roll_n", type=int, default=11)
    ap.add_argument("--pitch_min", type=float, default=-20.0)
    ap.add_argument("--pitch_max", type=float, default=20.0)
    ap.add_argument("--pitch_n", type=int, default=11)

    args = ap.parse_args()

    if args.viewpoints is None:
        # viewpoints 없이 순수 예제만 돌려보고 싶을 때:
        print("viewpoints 파일 없이 예제 pose로만 테스트합니다.")
        cam_pos = np.array([0.5, -0.1, 0.3])
        cam_quat = np.array([0.0, 0.0, 0.0, 1.0])
        target_pos = np.array([0.5, 0.0, 0.3])

        poses_roll, poses_pitch = generate_roll_pitch_tilts(
            cam_pos,
            cam_quat,
            target_pos,
            roll_min_deg=args.roll_min,
            roll_max_deg=args.roll_max,
            n_roll=args.roll_n,
            pitch_min_deg=args.pitch_min,
            pitch_max_deg=args.pitch_max,
            n_pitch=args.pitch_n,
        )
        print(f"[DEMO] roll poses:  {poses_roll.shape}")
        print(f"[DEMO] pitch poses: {poses_pitch.shape}")
        return

    # 실제 viewpoints.h5 기반
    info = generate_tilts_for_random_viewpoint(
        viewpoints_path=args.viewpoints,
        working_distance_m=args.wd,
        seed=args.seed,
        roll_min_deg=args.roll_min,
        roll_max_deg=args.roll_max,
        n_roll=args.roll_n,
        pitch_min_deg=args.pitch_min,
        pitch_max_deg=args.pitch_max,
        n_pitch=args.pitch_n,
    )

    print(f"Picked viewpoint index: {info['index']}")
    print(f"Target point (world):   {info['target_pos']}")
    print(f"Camera pos (world):     {info['cam_pos']}")
    print(f"Camera quat [x,y,z,w]:  {info['cam_quat_xyzw']}")
    print(f"Roll tilt poses shape:  {info['poses_roll'].shape}")
    print(f"Pitch tilt poses shape: {info['poses_pitch'].shape}")


if __name__ == "__main__":
    main()
