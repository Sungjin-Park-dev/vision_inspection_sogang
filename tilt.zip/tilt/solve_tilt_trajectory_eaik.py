#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
solve_tilt_with_utils.py

기능:
1. Tilt(Roll/Pitch) 웨이포인트 생성
2. common.ik_utils 모듈을 재사용하여 EAIK 계산 및 CuRobo 충돌 체크 수행
3. DP(Viterbi)로 최적 경로 탐색 및 CSV 저장


python scripts/solve_tilt_trajectory_eaik.py \
  --traj /home/lbj/curobo/vision_inspection/data/trajectory/675/gtsp_modified.csv \
  --row-idx 10 \
  --robot ur20.yml \
  --output data/trajectory/1158/tilt_utils_trajectory.csv \
  --roll-min -20 --roll-max 20 --roll-n 11 \
  --pitch-min -20 --pitch-max 20 --pitch-n 11
"""

import argparse
import csv
import sys
import os
import time
import numpy as np
import torch

# ---------------------------------------------------------------------
# 경로 설정 및 공통 모듈 임포트
# ---------------------------------------------------------------------
THIS_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.abspath(os.path.join(THIS_DIR, ".."))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from common import config
from common.world_setup import setup_collision_world
from common.ik_utils import (
    Viewpoint, 
    compute_ik_eaik, 
    assign_ik_solutions_to_viewpoints, 
    check_ik_solutions_collision
)
from tilt import generate_roll_pitch_tilts, quat_xyzw_to_rot

# CuRobo 관련 Imports (충돌 체커 설정용)
from curobo.types.base import TensorDeviceType
from curobo.wrap.reacher.ik_solver import IKSolver, IKSolverConfig
from curobo.geom.sdf.world import CollisionCheckerType
from curobo.util_file import load_yaml, join_path, get_robot_configs_path


# ---------------------------------------------------------------------
# 유틸리티 함수
# ---------------------------------------------------------------------
def load_pose_from_csv(traj_path, row_idx):
    """CSV에서 특정 Row의 포즈 로드"""
    with open(traj_path, "r", newline="") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    if row_idx < 0: row_idx = len(rows) // 2
    row = rows[row_idx]
    
    # 컬럼 이름 호환성 체크
    if "target-POS_X" in row:
        px, py, pz = float(row["target-POS_X"]), float(row["target-POS_Y"]), float(row["target-POS_Z"])
        qx, qy, qz, qw = float(row["target-ROT_X"]), float(row["target-ROT_Y"]), float(row["target-ROT_Z"]), float(row["target-ROT_W"])
    else:
        px, py, pz = float(row["px"]), float(row["py"]), float(row["pz"])
        qx, qy, qz, qw = float(row["qx"]), float(row["qy"]), float(row["qz"]), float(row["qw"])
        
    return np.array([px, py, pz]), np.array([qx, qy, qz, qw]) # xyzw

def setup_collision_checker(robot_config_file):
    """CuRobo IKSolver를 충돌 체크 전용으로 초기화"""
    print("[Init] Setting up collision world...")
    
    # 1. 월드 설정 (장애물 포함)
    world_cfg = setup_collision_world(
        table_position=config.TABLE_POSITION,
        table_dimensions=config.TABLE_DIMENSIONS,
        wall_position=config.WALL_POSITION,
        wall_dimensions=config.WALL_DIMENSIONS,
        workbench_position=config.WORKBENCH_POSITION,
        workbench_dimensions=config.WORKBENCH_DIMENSIONS,
        robot_mount_position=config.ROBOT_MOUNT_POSITION,
        robot_mount_dimensions=config.ROBOT_MOUNT_DIMENSIONS,
        mesh_files=[config.DEFAULT_MESH_FILE],
        mesh_position=config.GLASS_POSITION,
        mesh_rotation=config.GLASS_ROTATION,
        verbose=False
    )

    # 2. 로봇 설정 로드
    robot_cfg = load_yaml(join_path(get_robot_configs_path(), robot_config_file))["robot_cfg"]
    
    # 3. Solver 설정
    ik_config = IKSolverConfig.load_from_robot_config(
        robot_cfg,
        world_cfg,
        tensor_args=TensorDeviceType(device=torch.device("cuda:0"), dtype=torch.float32),
        self_collision_check=True,
        collision_checker_type=CollisionCheckerType.MESH,
        use_cuda_graph=True, 
    )
    
    return IKSolver(ik_config)

def run_dp_optimization(viewpoints: list[Viewpoint]):
    """
    DP (Viterbi) 알고리즘: Viewpoint 객체의 safe_ik_solutions를 사용해 최적 경로 탐색
    """
    n_steps = len(viewpoints)
    if n_steps == 0: return None
    
    # 입력 데이터 전처리: Viewpoint 객체에서 safe solutions 추출
    # List[np.ndarray(K, 6)] 형태
    solutions_list = []
    for vp in viewpoints:
        if len(vp.safe_ik_solutions) > 0:
            solutions_list.append(np.array(vp.safe_ik_solutions))
        else:
            solutions_list.append(np.empty((0, 6)))

    # 첫 스텝 확인
    if len(solutions_list[0]) == 0:
        print(f"[DP FAIL] Step 0 has no safe IK solutions.")
        return None

    # DP 테이블 초기화
    prev_costs = np.zeros(len(solutions_list[0]))
    paths = [[i] for i in range(len(solutions_list[0]))]
    
    for t in range(1, n_steps):
        curr_sols = solutions_list[t]
        prev_sols = solutions_list[t-1]
        
        if len(curr_sols) == 0:
            print(f"[DP FAIL] Step {t} has no safe IK solutions. Path blocked.")
            return None
            
        n_curr = len(curr_sols)
        
        # 거리 행렬 계산 (Broadcasting)
        diff = prev_sols[:, np.newaxis, :] - curr_sols[np.newaxis, :, :]
        dists = np.linalg.norm(diff, axis=2) # L2 Norm
        
        # 누적 비용
        total_costs = prev_costs[:, np.newaxis] + dists
        
        # 최적 부모 선택
        best_prev_indices = np.argmin(total_costs, axis=0) # (N_curr,)
        curr_costs = total_costs[best_prev_indices, np.arange(n_curr)]
        
        # 경로 업데이트
        new_paths = []
        for j in range(n_curr):
            parent_idx = best_prev_indices[j]
            new_paths.append(paths[parent_idx] + [j])
            
        prev_costs = curr_costs
        paths = new_paths
        prev_sols = curr_sols 
        
    # 최종 최소 비용 경로 선택
    best_final_idx = np.argmin(prev_costs)
    best_path_indices = paths[best_final_idx]
    
    # 궤적 생성
    optimal_trajectory = []
    for t, sol_idx in enumerate(best_path_indices):
        optimal_trajectory.append(solutions_list[t][sol_idx])
        
    return optimal_trajectory

def save_trajectory_csv(path, trajectory, poses_matrix):
    """CSV 저장"""
    headers = [
        "time", 
        "ur20-shoulder_pan_joint", "ur20-shoulder_lift_joint", "ur20-elbow_joint",
        "ur20-wrist_1_joint", "ur20-wrist_2_joint", "ur20-wrist_3_joint",
        "target-POS_X", "target-POS_Y", "target-POS_Z",
    ]
    
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(headers)
        for i, q in enumerate(trajectory):
            pos = poses_matrix[i, :3, 3]
            row = [float(i)] + q.tolist() + pos.tolist()
            w.writerow(row)
    print(f"[INFO] Saved trajectory to {path}")


# ---------------------------------------------------------------------
# 메인 함수
# ---------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Generate Tilt Trajectory using ik_utils")
    parser.add_argument("--traj", required=True, help="Input CSV trajectory file")
    parser.add_argument("--row-idx", type=int, default=10, help="Row index to use as center")
    parser.add_argument("--robot", type=str, default="ur20.yml", help="Robot config file")
    parser.add_argument("--output", type=str, default="tilt_utils_trajectory.csv", help="Output CSV file")
    
    # Tilt Parameter
    parser.add_argument("--roll-min", type=float, default=-20.0)
    parser.add_argument("--roll-max", type=float, default=20.0)
    parser.add_argument("--roll-n", type=int, default=11)
    parser.add_argument("--pitch-min", type=float, default=-20.0)
    parser.add_argument("--pitch-max", type=float, default=20.0)
    parser.add_argument("--pitch-n", type=int, default=11)
    
    args = parser.parse_args()
    
    # 1. Pose Load & Waypoint Gen
    print(f"[1] Loading pose & generating waypoints...")
    cam_pos, cam_quat = load_pose_from_csv(args.traj, args.row_idx)
    
    wd_m = config.get_camera_working_distance_m()
    R0 = quat_xyzw_to_rot(cam_quat)
    target_pos = cam_pos + R0[:, 2] * wd_m
    
    poses_roll, poses_pitch = generate_roll_pitch_tilts(
        cam_pos, cam_quat, target_pos,
        args.roll_min, args.roll_max, args.roll_n,
        args.pitch_min, args.pitch_max, args.pitch_n
    )
    full_poses = np.concatenate([poses_roll, poses_pitch], axis=0) # (N, 4, 4)
    print(f"    Total Waypoints: {len(full_poses)}")

    # 2. Convert to Viewpoint Objects (for ik_utils compatibility)
    # ik_utils의 함수들은 Viewpoint 객체 리스트를 입력으로 받습니다.
    viewpoints = []
    for i in range(len(full_poses)):
        # world_pose만 채워서 생성 (local_pose는 필요 없음)
        vp = Viewpoint(index=i, world_pose=full_poses[i])
        viewpoints.append(vp)
        
    # 3. Compute EAIK (Analytical IK)
    print(f"[2] Computing EAIK (using ik_utils)...")
    t0 = time.time()
    # compute_ik_eaik는 (N,4,4) numpy array를 받음
    ik_results = compute_ik_eaik(full_poses)
    
    # 결과를 Viewpoint 객체에 할당
    assign_ik_solutions_to_viewpoints(viewpoints, ik_results)
    print(f"    EAIK Done in {time.time()-t0:.4f}s")
    
    # 4. Check Collisions (CuRobo Batch)
    print(f"[3] Checking Collisions (using ik_utils)...")
    ik_solver = setup_collision_checker(args.robot)
    
    t0 = time.time()
    # ik_utils 내부에서 Batch Gather -> Check -> Scatter 수행
    check_ik_solutions_collision(viewpoints, ik_solver)
    print(f"    Collision Check Done in {time.time()-t0:.4f}s")
    
    # 5. DP Optimization
    print(f"[4] Optimizing Path (DP)...")
    optimal_traj = run_dp_optimization(viewpoints)
    
    if optimal_traj is None:
        print("\n[FAIL] No valid trajectory found.")
        sys.exit(1)
        
    # 6. Save
    print(f"[5] Saving Result...")
    save_trajectory_csv(args.output, optimal_traj, full_poses)
    print("Done!")

if __name__ == "__main__":
    main()